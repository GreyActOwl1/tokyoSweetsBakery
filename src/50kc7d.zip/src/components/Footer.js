import * as React from "react";
import {
  Navbar,
  NavbarBrand,
  Collapse,
  NavbarToggler,
  Nav,
  NavItem,
  Container,
  Row,
  Col
} from "reactstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { NavLink } from "react-router-dom";
import "font-awesome/css/font-awesome.min.css";
import { Link } from "react-router-dom";
import "../styles.css";

const Footer = () => {
  return (
    <footer>
      {" "}
      <Container className="pt-5" fluid>
        <Row className="mx-auto">
          <Col md="4" className="text-center">
            <p>505 Moore Street, Pocahontas, VA 24605, USA</p>
            <p>&copy; Tokyo Sweets Bakery</p>
          </Col>
          <Col md="4" className="text-center d-flex-column">
            <h5> Main Menu </h5>
            <ul className="list-unstyled d-flex flex-md-column text-center justify-content-md-center justify-content-evenly">
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/directory">About</Link>
              </li>
              <li>
                <Link to="/about">Shop</Link>
              </li>
              <li>
                <Link to="/contact">Contact Us</Link>
              </li>
            </ul>
          </Col>
          <Col md="4" className="text-center">
            <h5>Social</h5>
            <a
              className="btn btn-social-icon btn-instagram"
              href="http://instagram.com/"
            >
              <i className="fa fa-instagram" />
            </a>{" "}
            <a
              className="btn btn-social-icon btn-facebook"
              href="http://www.facebook.com/"
            >
              <i className="fa fa-facebook-official" />
            </a>{" "}
            <a
              className="btn btn-social-icon btn-twitter"
              href="http://twitter.com/"
            >
              <i className="fa fa-twitter" />
            </a>{" "}
            <a
              className="btn btn-social-icon btn-google"
              href="http://youtube.com/"
            >
              <i className="fa fa-youtube" />
            </a>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
